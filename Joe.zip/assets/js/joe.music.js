/**
 * @package Joe再续前缘版全局音乐
 * @author 易航
 * @link http://blog.bri6.cn
*/
class music_player {

	constructor() {
		/**
		* 要播放的音乐
		*/
		this.MUSIC = null;

		/**
		* 播放器
		*/
		this.PLAYER = null;

		/**
		* 存储的音乐信息
		*/
		this.MUSIC_STORAGE = null;
	}

	/**
	 * 初始化播放器
	 */
	init() {
		this.createPlayer();
		this.initStorageMusic();
		if (!this.MUSIC_STORAGE) {
			this.requestMusic();
		}
		this.listen();
		this.playMusic();
	}

	/**
	 * 监听播放器事件
	 */
	listen() {
		window.onbeforeunload = () => {
			this.storageMusic();
		}
		document.getElementsByTagName('a').onclick = () => {
			this.storageMusic();
		}
		this.PLAYER.on('loadeddata', () => {
			if (this.MUSIC_STORAGE) {
				this.PLAYER.seek(this.MUSIC_STORAGE.time);
				this.MUSIC_STORAGE = null;
			}
			this.setTheme(this.PLAYER.list.index);
			console.log(`%c当前音乐链接：%c${this.PLAYER.audio.src}`, 'color:#fff; background: linear-gradient(270deg, #fadfa3,#000); padding: 8px 0px 8px 8px;margin-right:0px; border-radius: 6px 0px 0px 6px;', 'background: #fadfa3; padding: 8px 8px 8px 8px;border-radius: 0px 6px 6px 0px;');
			this.requestMusic();
			this.PLAYER.list.add([this.MUSIC]);
		});
		this.PLAYER.on('error', () => {
			this.requestMusic();
			this.playMusic();
			this.PLAYER.seek(0);
		});
	}

	/**
	 * 创建播放器
	 */
	createPlayer() {
		if (!document.getElementById('player')) {
			this.createElementHtml('player', 'div');
		}
		this.PLAYER = new APlayer({
			container: document.getElementById('player'), // 播放器容器元素
			autoplay: true, //自动播放
			theme: '#1989fa', //默认主题色
			loop: 'all', //循环播放, 可选值: 'all', 'one', 'none'
			order: 'list', //循环顺序, 可选值: 'list', 'random'
			volume: 1, //默认音量
			fixed: true, //吸底模式
			lrcType: 1,
			preload: 'auto', //预加载，可选值: 'none', 'metadata', 'auto'
			mutex: false //互斥，阻止多个播放器同时播放，当前播放器播放时暂停其他播放器
		});
	}

	/**
	 * 播放音乐
	 */
	playMusic() {
		this.PLAYER.list.add([this.MUSIC]);
		this.PLAYER.skipForward();
		this.PLAYER.play();
	}

	/**
	 * 请求音乐
	 */
	requestMusic() {
		let requestMusic = this.ajax(Joe.BASE_API, 'POST', `routeType=music_list`);
		let response = this.ajax(`https://www.vvhan.com/usr/themes/Joe/NeteaseCloudMusicApi.php?id=${requestMusic.id}`)[0];
		let music_data = {
			name: response.title,
			artist: response.author,
			url: response.url,
			cover: response.pic,
			lrc: response.lrc
		};
		this.MUSIC = music_data;
		this.setMusic();
	}

	/**
	 * 优化音乐信息
	 * @return object
	 */
	setMusic() {
		// 音频名称
		if (!this.MUSIC['name']) {
			this.MUSIC['name'] = '这是一首歌';
		}
		// 音频作者
		if (!this.MUSIC['artist']) {
			this.MUSIC['artist'] = '无信息';
		}
		// 音频类型
		if (!this.MUSIC['type']) {
			this.MUSIC['type'] = 'auto';
		}
		// 音频封面
		if (!this.MUSIC['cover']) {
			this.MUSIC['cover'] = 'http://cdn.bri6.cn/images/202208032036881.jpg';
		}
		// 音频歌词
		if (!this.MUSIC['lrc']) {
			this.MUSIC['lrc'] = '[00:00.000] 暂无歌词';
		}
		return this.MUSIC;
	}

	/**
	 * 初始化存储音乐信息
	 */
	initStorageMusic() {
		let music_storage = this.getMusic();
		if (music_storage) {
			this.MUSIC_STORAGE = music_storage;
			this.MUSIC = music_storage;
		}
	}

	/**
	 * 获取存储的音乐信息
	 * @return object
	 */
	getMusic() {
		if (localStorage.getItem('music')) {
			return JSON.parse(localStorage.getItem('music'));
		}
		return null;
	}

	/**
	 * 存储音乐
	 */
	storageMusic() {
		let music = this.PLAYER.list.audios[this.PLAYER.list.index]
		music.time = this.PLAYER.audio.currentTime;
		localStorage.setItem('music', JSON.stringify(music));
	}

	/**
	 * 音乐播放器自动主题色
	 */
	setTheme(index) {
		if (this.PLAYER.list.audios[index]) {
			if (!this.PLAYER.list.audios[index].theme) {
				let xhr = new XMLHttpRequest();
				xhr.open('GET', this.PLAYER.list.audios[index].cover, true);
				xhr.responseType = 'blob';
				xhr.send();
				xhr.onload = () => {
					var coverUrl = URL.createObjectURL(xhr.response);
					let image = new Image();
					image.onload = () => {
						let colorThief = new ColorThief();
						let color = colorThief.getColor(image);
						this.PLAYER.theme(`rgb(${color[0]}, ${color[1]}, ${color[2]})`, index);
						URL.revokeObjectURL(coverUrl)
					};
					image.src = coverUrl;
				}
			}
		}
	}

	/**
	 * 创建HTML元素
	 * @param id 元素ID值
	 * @param tagname 标签
	 * @return innerHTML
	 */
	createElementHtml(id, tagname) {
		var containerdiv = document.createElement('div'),
			nwtag = document.createElement(tagname);
		nwtag.id = id;
		document.body.appendChild(nwtag);
		return containerdiv.innerHTML;
	}

	ajax(url, type = 'GET', param = null) {
		var xhr = window.XMLHttpRequest ? new XMLHttpRequest() : new ActiveXObject('Microsoft.XMLHTTP');
		xhr.open(type, url, false);
		if (type == 'POST') {
			xhr.setRequestHeader("content-type", "application/x-www-form-urlencoded");
			xhr.send(param);
		} else {
			xhr.send();
		}
		return JSON.parse(xhr.responseText);
		console.log(xhr)
		return xhr;
	}
}

$(() => {
	new music_player().init();
});